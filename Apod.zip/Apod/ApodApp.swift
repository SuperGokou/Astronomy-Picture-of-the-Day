//
//  ApodApp.swift
//  Apod
//
//  Created by Ming Xia on 4/2/22.
//

import SwiftUI

@main
struct ApodApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
